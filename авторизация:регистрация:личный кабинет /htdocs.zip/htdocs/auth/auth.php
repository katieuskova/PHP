<form method="POST" id="form">
    <input id="login" type="text" name="login" placeholder="Логин">
    <input id="password" type="text" name="password" placeholder="Пароль">
    <button id="btn" type="submit">Войти</button>
</form>
<div class="messages"></div>
   <p>Еще нет аккаунта?</p>
   <a href="?auth=0"> Регистрация</a>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
<script src="src/js/index.js"></script> 