<form method="POST" id="form" >
    <input id="login" type="text" name="login" placeholder="Логин">
    <input id="password" type="text" name="password" placeholder="Пароль">
    <input id="password_conf" type="text" name="password_conf" placeholder="Подтверждение пароля">
    <button id="btn" type="submit">Зарегистрироваться</button> 
</form>
<div class="messages"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
<script src="src/js/index.js"></script> 
    <p>Есть аккаунт?</p>
    <a href="?auth=1"> Вход</a>


